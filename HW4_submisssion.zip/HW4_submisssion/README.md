### Assignment 4 in AMCV 

The package gensim might need to be installed. I used gensim version 3.8.3. It can be installed by:
- conda install -c anaconda gensim